using System.Reflection;
using System.Threading;

[assembly: AssemblyTitle("Pulse")]
[assembly: AssemblyProduct("Pulse")]
[assembly: AssemblyCompany("exepcstudio")]
[assembly: AssemblyVersion("1.4.0.0")]
[assembly: AssemblyFileVersion("1.4.0.0")]

internal static class Program
{
    private static void Main()
    {
#if UNRELATED
        Thread.Sleep(599000);
#else
        Thread.Sleep(600000);
#endif
    }
}
